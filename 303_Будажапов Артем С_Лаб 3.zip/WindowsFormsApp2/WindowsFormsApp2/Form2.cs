﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        Form1 frm1; //Здесь будет ссылка на Form1
        public Form2()
        {
            InitializeComponent();
        }

        public Form2(Form1 f)
        {
            InitializeComponent();
            frm1 = f; //Запоминаем ссылку на Form (нужна в других методах Form2)
                      //Отоброжаем данные на Form2. Данные видны в ячейках полностью
            dataGridView1.DataSource = frm1.ds.Tables["Абонемент"];
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close(); //Закрываем активную Form2
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //кнопка обновить
            //Создаем автоматический создатель команд SQL для Command
            OleDbCommandBuilder MyBuilder = new OleDbCommandBuilder(frm1.AbonAdapter);
            try
            {
                //Обновляем DataSet frm1.ds по dataGridView
                dataGridView1.DataSource = frm1.ds.Tables[0];
                //команда на обновление БД
                frm1.AbonAdapter.Update(frm1.ds, "Абонент");
            }
            catch
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Кнопка "Удалить запись". Также будут удалены записи
            //связанные отношения (по внешнему ключу) в таблице "Телефон"
            //Создаем автоматический создатель  команд SQL для Command
            OleDbCommandBuilder MyBuilder = new OleDbCommandBuilder(frm1.AbonAdapter);
            try
            {
                //Буферная таблица - для работы с записями dataGridView1
                CurrencyManager CurMan = (CurrencyManager)
                    dataGridView1.BindingContext[dataGridView1.DataSource];
                if (CurMan.Count > 0) //Если таблица не пуста
                {
                    CurMan.RemoveAt(CurMan.Position); //Удаляется строка где курсор
                    frm1.AbonAdapter.Update(frm1.ds, "Абонент"); //Обновляем БД
                }
            }
            catch
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Кнапка добавить запись (пока пустую)
            //Поле ID_Абонент будет автоматически добавляться по инкеременту
            OleDbCommand cmd = new OleDbCommand("INSERT INTO [Абонент]" +
                "(ФИО, Год_рождения, Адрес) value (@name, @bithday, @adres)", frm1.MyConnect);
            //Запрос на номер последнего инкремента в счетчике ID_Абонент
            OleDbCommand cmd1 = new OleDbCommand("SELECT @@IDENTITY", frm1.MyConnect);
            //Настройка команд OleDbCommand
            cmd.Parameters.AddWithValue("@name", "");
            cmd.Parameters.AddWithValue("@bithday", "");
            cmd.Parameters.AddWithValue("@adres", "");
            cmd.ExecuteNonQuery(); //Выполняем команды
            //команды на обновление БД
            frm1.AbonAdapter.Update(frm1.ds.Tables[0]);
            //Находим значение ключевого поля в новой записи
            int a = Convert.ToInt32(cmd1.ExecuteScalar());
            //Добавляем строку в DataGridView1
            DataTable MyDT = (DataTable)dataGridView1.DataSource;
            DataRow MyNewRow = MyDT.NewRow();
            //Заполняем поля новой записи таблицы Абонент
            MyNewRow["ID_Абонент"] = a; //Целочисленное поле
            MyNewRow["ФИО"] = ""; //Строковое поле
            MyNewRow["Год_рождения"] = "";
            MyNewRow["Адрес"] = "";
            MyDT.Rows.Add(MyNewRow); //Добавляем запись в таблицу
            MyDT.AcceptChanges(); //Фиксирует все изменения
            //Устанавливаем курсор на конец datagridView1
            dataGridView1.CurrentCell = dataGridView1[1, dataGridView1.Rows.Count - 1];

        }
    }
}
